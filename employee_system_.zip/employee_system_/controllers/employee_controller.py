from flask import Blueprint, render_template, request, redirect, flash
from flask_login import login_required
from extensions import mysql
from services.employee_service import EmployeeService

employee_bp = Blueprint('employee', __name__)
employee_service = EmployeeService(mysql)

@employee_bp.route('/')
@login_required
def list_employees():
    model = employee_service.model
    employees = model.get_all()
    return render_template('index.html', employees=employees)

@employee_bp.route('/add', methods=['GET', 'POST'])
@login_required
def add():
    if request.method == 'POST':
        data = request.form
        photo = request.files['photo']
        employee_service.add_employee(data, photo, 'uploads')
        flash('Employee added')
        return redirect('/')
    return render_template('add_edit.html', action='Add', emp=None)

@employee_bp.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit(id):
    model = employee_service.model
    if request.method == 'POST':
        model.update(id, request.form)
        flash('Employee updated')
        return redirect('/')
    emp = model.get_by_id(id)
    return render_template('add_edit.html', action='Edit', emp=emp)

@employee_bp.route('/delete/<int:id>')
@login_required
def delete(id):
    model = employee_service.model
    model.delete(id)
    flash('Employee deleted')
    return redirect('/')
