from flask import Blueprint, render_template, jsonify, request, redirect, make_response
from flask_login import login_required, current_user
from services.attendance_service import AttendanceService
from extensions import mysql
from datetime import date
import os
import base64
import csv
from io import StringIO

attendance_bp = Blueprint('attendance', __name__)
service = AttendanceService()

def is_admin():
    return current_user and str(current_user.id).isdigit() == False

# ==== QR Scan Page ====
@attendance_bp.route('/scan')
@login_required
def scan():
    return render_template('scan.html')

# ==== Mark Attendance after QR Scan ====
@attendance_bp.route('/mark_attendance', methods=['POST'])
@login_required
def mark():
    emp_id = request.get_json()['employee_id']
    return jsonify({'message': service.mark_attendance(emp_id)})

# ==== Capture Photo from Webcam ====
@attendance_bp.route('/capture_photo', methods=['POST'])
@login_required
def capture_photo():
    data = request.get_json()
    image_data = data['photo'].split(',')[1]  # remove "data:image/png;base64,"
    photo_binary = base64.b64decode(image_data)

    photo_filename = f"{current_user.id}_{date.today()}.png"
    photo_path = os.path.join('uploads', photo_filename)

    with open(photo_path, 'wb') as f:
        f.write(photo_binary)

    # Update photo in employee table
    cur = mysql.connection.cursor()
    cur.execute("UPDATE employees SET photo = %s WHERE id = %s", (photo_filename, current_user.id))
    mysql.connection.commit()

    return jsonify({'message': 'Photo captured and saved successfully.'})

# ==== Dashboard ====
@attendance_bp.route('/dashboard')
@login_required
def dashboard():
    if not is_admin():
        return redirect('/')

    today = date.today()
    cur = mysql.connection.cursor()

    cur.execute("SELECT COUNT(*) FROM employees")
    total = cur.fetchone()[0]

    cur.execute("SELECT COUNT(*) FROM attendance WHERE date=%s", [today])
    present = cur.fetchone()[0]

    cur.execute("""
        SELECT e.name, a.date, a.sign_in, a.sign_out 
        FROM attendance a 
        JOIN employees e ON e.id = a.employee_id 
        ORDER BY a.date DESC
    """)
    records = cur.fetchall()

    cur.execute("SELECT date, COUNT(*) FROM attendance GROUP BY date ORDER BY date ASC LIMIT 10")
    trends = cur.fetchall()
    labels = [str(row[0]) for row in trends]
    values = [row[1] for row in trends]

    cur.execute("SELECT * FROM employees")
    employees = cur.fetchall()

    return render_template('dashboard.html', present=present, absent=total-present, total=total,
                           records=records, labels=labels, values=values, employees=employees)

# ==== Export Attendance CSV ====
@attendance_bp.route('/export_attendance')
@login_required
def export_attendance():
    if not is_admin():
        return redirect('/')

    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT e.name, a.date, a.sign_in, a.sign_out 
        FROM attendance a 
        JOIN employees e ON e.id = a.employee_id 
        ORDER BY a.date DESC
    """)
    data = cur.fetchall()

    si = StringIO()
    cw = csv.writer(si)
    cw.writerow(['Name', 'Date', 'Sign In', 'Sign Out'])
    cw.writerows(data)

    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename=attendance.csv"
    output.headers["Content-type"] = "text/csv"
    return output

# ==== Employee Cards ====
@attendance_bp.route('/employee_cards')
@login_required
def employee_cards():
    if not is_admin():
        return redirect('/')

    cur = mysql.connection.cursor()
    cur.execute("SELECT id, name, username, photo FROM employees")
    employees = cur.fetchall()
    return render_template('employee_cards.html', employees=employees)

# ==== Chat Page ====
@attendance_bp.route('/chat')
@login_required
def chat():
    return render_template('chat.html')

# ==== Chatbot Logic ====
@attendance_bp.route('/chatbot', methods=['POST'])
@login_required
def chatbot():
    query = request.get_json()['query'].lower()
    cur = mysql.connection.cursor()
    today = date.today()

    if 'present' in query and 'today' in query:
        cur.execute("SELECT COUNT(*) FROM attendance WHERE date = %s", [today])
        count = cur.fetchone()[0]
        return jsonify({'response': f"{count} employees are present today."})

    elif 'total' in query and 'employees' in query:
        cur.execute("SELECT COUNT(*) FROM employees")
        count = cur.fetchone()[0]
        return jsonify({'response': f"There are {count} total employees."})

    elif 'absent' in query and 'today' in query:
        cur.execute("SELECT COUNT(*) FROM employees")
        total = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM attendance WHERE date = %s", [today])
        present = cur.fetchone()[0]
        absent = total - present
        return jsonify({'response': f"{absent} employees are absent today."})

    elif 'male' in query or 'female' in query:
        cur.execute("SELECT gender, COUNT(*) FROM employees GROUP BY gender")
        results = cur.fetchall()
        text = ', '.join([f"{gender}: {count}" for gender, count in results])
        return jsonify({'response': f"Gender breakdown: {text}"})

    elif 'attendance' in query and 'today' in query:
        cur.execute("""
            SELECT e.name, a.sign_in, a.sign_out
            FROM attendance a
            JOIN employees e ON e.id = a.employee_id
            WHERE a.date = %s
        """, [today])
        rows = cur.fetchall()
        if rows:
            text = '<br>'.join([f"{r[0]} - IN: {r[1]} OUT: {r[2] or 'N/A'}" for r in rows])
            return jsonify({'response': text})
        else:
            return jsonify({'response': 'No attendance records today.'})

    else:
        return jsonify({'response': "Sorry, I didn't understand that. Try asking about attendance, employee count, or gender."})
