from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_required, logout_user
from services.auth_service import AuthService

auth_bp = Blueprint('auth', __name__)
auth_service = AuthService()

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if auth_service.login(request.form['username'], request.form['password']):
            return redirect('/')
        flash('Invalid credentials')
    return render_template('login.html')

@auth_bp.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))
