from models.employee_model import Employee
import os, qrcode

class EmployeeService:
    def __init__(self, mysql):
        self.model = Employee(mysql)

    def add_employee(self, data, photo, upload_folder):
        filename = photo.filename
        path = os.path.join(upload_folder, filename)
        photo.save(path)
        emp_id = self.model.add(data, filename)

        # Generate QR
        qr = qrcode.make(str(emp_id))
        qr_dir = os.path.join('static/qrcodes')
        os.makedirs(qr_dir, exist_ok=True)
        qr.save(os.path.join(qr_dir, f"{emp_id}.png"))
        return emp_id
