class Employee:
    def __init__(self, mysql):
        self.mysql = mysql

    def get_all(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM employees")
        return cur.fetchall()

    def get_by_id(self, emp_id):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM employees WHERE id = %s", [emp_id])
        return cur.fetchone()

    def add(self, data, filename):
        cur = self.mysql.connection.cursor()
        cur.execute("INSERT INTO employees (name, username, email, password, city, photo) VALUES (%s, %s, %s, %s, %s, %s)",
                    (data['name'], data['username'], data['email'], data['password'], data['city'], filename))
        self.mysql.connection.commit()
        return cur.lastrowid

    def update(self, emp_id, data):
        cur = self.mysql.connection.cursor()
        cur.execute("UPDATE employees SET name=%s, username=%s, email=%s, password=%s, city=%s WHERE id=%s",
                    (data['name'], data['username'], data['email'], data['password'], data['city'], emp_id))
        self.mysql.connection.commit()

    def delete(self, emp_id):
        cur = self.mysql.connection.cursor()
        cur.execute("DELETE FROM employees WHERE id=%s", [emp_id])
        self.mysql.connection.commit()