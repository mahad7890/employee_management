from flask import Flask
from config import Config
from extensions import mysql, login_manager
from controllers.auth_controller import auth_bp
from controllers.employee_controller import employee_bp
from controllers.attendance_controller import attendance_bp
from models.user_model import User

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # Initialize extensions
    mysql.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'

    # Register Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(employee_bp)
    app.register_blueprint(attendance_bp)

    # Define user loader for Flask-Login
    @login_manager.user_loader
    def load_user(user_id):
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, username FROM users WHERE id = %s", [user_id])
        user = cur.fetchone()
        return User(user[0], user[1]) if user else None

    return app

# Run the app
app = create_app()

if __name__ == '__main__':
    app.run(debug=True)
