from flask_mysqldb import MySQL
from flask_login import LoginManager
from models.user_model import User  # Ensure this exists
                                    # You can move this to app.py too

mysql = MySQL()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'

@login_manager.user_loader
def load_user(user_id):
    cur = mysql.connection.cursor()
    cur.execute("SELECT id, username FROM users WHERE id = %s", [user_id])
    user = cur.fetchone()
    return User(user[0], user[1]) if user else None
