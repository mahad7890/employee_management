from flask import Flask
from flask_mysqldb import MySQL
from flask_login import LoginManager
from config import Config

# Initialize extensions
mysql = MySQL()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # Initialize extensions
    mysql.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    
    # Initialize database tables
    with app.app_context():
        from models.book import Book
        from models.member import Member
        from models.transaction import Transaction
        from models.user import User
        
        Book(mysql).create_table()
        Member(mysql).create_table()
        Transaction(mysql).create_table()
        User(mysql).create_table()
    
    # Register blueprints
    from controllers.auth_controller import auth_bp
    from controllers.book_controller import book_bp
    from controllers.member_controller import member_bp
    from controllers.transaction_controller import transaction_bp
    
    app.register_blueprint(auth_bp)
    app.register_blueprint(book_bp)
    app.register_blueprint(member_bp)
    app.register_blueprint(transaction_bp)
    
    return app

if __name__ == '__main__':
    app = create_app()
    app.run(debug=True)