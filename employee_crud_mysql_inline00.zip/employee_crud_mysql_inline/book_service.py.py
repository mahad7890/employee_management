from models.book import Book

class BookService:
    def __init__(self, mysql):
        self.book_model = Book(mysql)
    
    def get_all_books(self):
        return self.book_model.get_all_books()
    
    def add_book(self, title, author, isbn, quantity, category):
        return self.book_model.add_book(title, author, isbn, quantity, category)
    
    # Additional service methods...