from flask_mysqldb import MySQL
from datetime import datetime

class Book:
    def __init__(self, mysql):
        self.mysql = mysql
    
    def create_table(self):
        cur = self.mysql.connection.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS books (
                book_id INT AUTO_INCREMENT PRIMARY KEY,
                title VARCHAR(100) NOT NULL,
                author VARCHAR(50) NOT NULL,
                isbn VARCHAR(20) UNIQUE NOT NULL,
                quantity INT DEFAULT 1,
                category VARCHAR(30),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        self.mysql.connection.commit()
    
    def add_book(self, title, author, isbn, quantity, category):
        cur = self.mysql.connection.cursor()
        cur.execute("""
            INSERT INTO books (title, author, isbn, quantity, category)
            VALUES (%s, %s, %s, %s, %s)
        """, (title, author, isbn, quantity, category))
        self.mysql.connection.commit()
        return cur.lastrowid
    
    def get_all_books(self):
        cur = self.mysql.connection.cursor()
        cur.execute("SELECT * FROM books")
        return cur.fetchall()
    
    # Additional book methods...