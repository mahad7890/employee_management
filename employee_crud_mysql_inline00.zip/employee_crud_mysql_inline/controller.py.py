from flask import render_template, request, redirect, url_for, flash
from services.book_service import BookService

class BookController:
    def __init__(self, book_service):
        self.book_service = book_service
    
    def list_books(self):
        books = self.book_service.get_all_books()
        return render_template('books/list.html', books=books)
    
    def add_book(self):
        if request.method == 'POST':
            title = request.form['title']
            author = request.form['author']
            isbn = request.form['isbn']
            quantity = request.form['quantity']
            category = request.form['category']
            
            self.book_service.add_book(title, author, isbn, quantity, category)
            flash('Book added successfully!', 'success')
            return redirect(url_for('books.list'))
        
        return render_template('books/add.html')
    
    # Additional controller methods...